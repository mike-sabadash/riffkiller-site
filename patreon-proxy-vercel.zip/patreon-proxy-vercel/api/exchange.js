/**
 * Patreon OAuth token exchange proxy – run on Vercel (US region) to avoid
 * Cloudflare error 1009 (country/region banned) when your production server IP is blocked.
 *
 * Set PATREON_CLIENT_ID and PATREON_CLIENT_SECRET in Vercel Environment Variables.
 * Deploy, then set PATREON_PROXY_URL on your server to this function URL (e.g. https://xxx.vercel.app/api/exchange).
 */

const ALLOW_ORIGIN = 'https://riffkiller.fun';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }
  if (req.method !== 'POST') {
    res.status(405).json({ success: false, error: 'Method not allowed' });
    return;
  }

  const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  const code = body.code;
  const redirectUri = body.redirect_uri || 'https://riffkiller.fun/patreon-callback.html';

  if (!code) {
    res.status(400).json({ success: false, error: 'No code provided' });
    return;
  }

  const clientId = process.env.PATREON_CLIENT_ID;
  const clientSecret = process.env.PATREON_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    res.status(500).json({ success: false, error: 'Proxy misconfigured: missing PATREON_CLIENT_ID or PATREON_CLIENT_SECRET' });
    return;
  }

  // 1) Token exchange
  const tokenRes = await fetch('https://www.patreon.com/api/oauth2/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': 'RiffKiller/1.0 (https://riffkiller.fun)',
      Accept: 'application/json',
    },
    body: new URLSearchParams({
      code,
      grant_type: 'authorization_code',
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
    }).toString(),
  });

  const tokenText = await tokenRes.text();
  const tokenData = tokenText ? JSON.parse(tokenText) : {};

  if (tokenRes.status !== 200) {
    const errDesc = tokenData.error_description || tokenData.error || tokenText || 'Unknown';
    res.status(200).json({
      success: false,
      error: tokenData.error === 'invalid_grant' ? 'Redirect URI mismatch or code expired.' : errDesc,
      patreon_error: tokenData.error,
      patreon_description: tokenData.error_description,
      http_code: tokenRes.status,
    });
    return;
  }

  const accessToken = tokenData.access_token;
  if (!accessToken) {
    res.status(400).json({ success: false, error: 'No access token received' });
    return;
  }

  // 2) Identity
  const identityRes = await fetch(
    'https://www.patreon.com/api/oauth2/v2/identity?include=memberships&fields[user]=full_name,email,image_url',
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'User-Agent': 'RiffKiller/1.0 (https://riffkiller.fun)',
      },
    }
  );
  const userData = await identityRes.json().catch(() => ({}));

  if (identityRes.status !== 200) {
    res.status(identityRes.status).json({
      success: false,
      error: 'Failed to get user data',
      details: userData,
    });
    return;
  }

  let subscriptionStatus = 'inactive';
  const included = userData.included || [];
  for (const inc of included) {
    if (inc.type === 'member') {
      const status = inc.attributes?.patron_status || 'inactive';
      subscriptionStatus = status === 'active_patron' ? 'active' : 'inactive';
      break;
    }
  }

  const out = {
    success: true,
    token: {
      access_token: accessToken,
      refresh_token: tokenData.refresh_token || null,
      expires_in: tokenData.expires_in || 3600,
    },
    user: {
      id: userData.data?.id ?? null,
      full_name: userData.data?.attributes?.full_name ?? 'User',
      email: userData.data?.attributes?.email ?? '',
      image_url: userData.data?.attributes?.image_url ?? 'assets/icons/default-avatar.svg',
    },
    subscription: { status: subscriptionStatus },
  };

  res.status(200).json(out);
}
